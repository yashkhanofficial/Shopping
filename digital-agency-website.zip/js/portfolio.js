/**
 * AURA Digital — Portfolio Filter & Gallery
 */
document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('portfolioGallery');
  if (!container) return;

  const projects = [
    { title: 'Hyperion Capital Portal', cat: 'Web Development', img: 'assets/images/web-dev.jpg', metric: '+185% Engagement' },
    { title: 'Verve Soundworks Release', cat: 'Music & Artwork', img: 'assets/images/music.jpg', metric: 'Top 20 Dance Chart' },
    { title: 'Apex Dynamics Film', cat: 'Video Production', img: 'assets/images/video.jpg', metric: '1.2M Organic Views' },
    { title: 'Creator Breakthrough CTR Suite', cat: 'YouTube Thumbnail Design', img: 'assets/images/web-dev.jpg', metric: '+42% Average CTR' },
    { title: 'AeroSphere Mobility', cat: 'Social Media', img: 'assets/images/hero.jpg', metric: '+340k Followers' },
    { title: 'Solstice Collective Entity', cat: 'Knowledge Panel', img: 'assets/images/hero.jpg', metric: 'Entity Indexed' }
  ];

  container.innerHTML = projects.map(p => `
    <div class="card">
      <div class="card-img-wrap">
        <img src="${p.img}" alt="${p.title}" loading="lazy">
      </div>
      <div class="card-badge">Demo Project · ${p.cat}</div>
      <h3 class="card-title">${p.title}</h3>
      <p class="card-desc">Comprehensive agency demonstration showcasing our visual engineering, sound sync, and conversion benchmarks.</p>
      <div class="card-meta">
        <span style="color: #34D399; font-weight: 600;">${p.metric}</span>
        <a href="contact.html" style="color: #6366F1; font-weight: 600;">Request Similar →</a>
      </div>
    </div>
  `).join('');
});
