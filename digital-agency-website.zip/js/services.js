/**
 * AURA Digital — Services Loader
 */
document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('servicesList');
  if (!container) return;

  try {
    const res = await fetch('data/services.json');
    const data = await res.json();
    
    container.innerHTML = data.services.map(s => `
      <div class="card">
        <div class="card-img-wrap">
          <img src="${s.image}" alt="${s.title}" loading="lazy">
        </div>
        <div class="card-badge">${s.badge}</div>
        <h3 class="card-title">${s.title}</h3>
        <p class="card-desc">${s.shortDesc}</p>
        <div class="card-meta">
          <span>${s.timeline}</span>
          <span class="price-tag">From ${s.startingPrice}</span>
        </div>
        <div style="margin-top: 1rem;">
          <a href="contact.html?service=${s.id}" class="btn btn-secondary" style="width: 100%;">Inquire About Service</a>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error('Could not load services JSON:', err);
  }
});
