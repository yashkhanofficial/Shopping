/**
 * AURA Digital — Forms & Inquiry Handler
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('quoteForm');
  const waBtn = document.getElementById('waDirectBtn');
  const AGENCY_WHATSAPP_NUMBER = '15550192834';

  function updateWhatsAppLink() {
    if (!waBtn) return;
    const name = document.getElementById('name')?.value || 'Client';
    const service = document.getElementById('service')?.value || 'Digital Services';
    const brief = document.getElementById('brief')?.value || 'I would like to discuss my project requirements.';
    
    const text = encodeURIComponent(
      `Hello AURA Digital team,\n\nMy name is ${name}. I am inquiring about: *${service}*.\n\n*Brief:* ${brief}`
    );
    waBtn.href = `https://wa.me/${AGENCY_WHATSAPP_NUMBER}?text=${text}`;
  }

  if (form) {
    form.addEventListener('input', updateWhatsAppLink);
    updateWhatsAppLink();

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const service = document.getElementById('service').value;

      alert(`Thank you, ${name}! Your inquiry for ${service} has been received. Our senior director will review your brief and respond to ${email} within 24 hours.`);
      form.reset();
      updateWhatsAppLink();
    });
  }
});
