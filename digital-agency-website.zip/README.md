# AURA Digital — Premium Modern Digital Agency Website

Welcome to **AURA Digital**, a high-end, responsive, conversion-optimized digital agency website engineered using semantic HTML5, modern CSS3, and clean Vanilla JavaScript.

---

## 1. Project Overview & Architecture

This package provides a professional digital agency web presence designed for high visual distinction, creator retention, and clear service presentation:
- **Web Development**: Business, e-commerce, custom web applications, responsive tuning.
- **Social Media Management**: Facebook, Instagram, YouTube channel growth, post design, analytics.
- **Video Editing**: Cinematic YouTube long-form, Reels/Shorts, motion graphics, audio synchronization.
- **YouTube Thumbnail Design**: High-contrast, mobile-optimized CTR composition.
- **Music Distribution Guidance**: Independent release preparation, metadata compliance, 3000x3000px artwork.
- **Google Knowledge Panel Services**: Entity authority consultation, Schema.org structured data.

### Directory Structure
```
digital-agency-website/
├── index.html                  # Landing page (Hero, stats, featured services, workflow, CTA)
├── services.html               # Comprehensive service catalog & deliverables
├── about.html                  # Agency origin, philosophy, values & workflow
├── portfolio.html              # Curated showcase gallery with demo concept tags
├── pricing.html                # Service packages (Essential, Growth, Enterprise)
├── contact.html                # Validated project inquiry form & WhatsApp generator
├── css/
│   ├── style.css               # Core design system, typography, colors, layout
│   ├── responsive.css          # Breakpoints (1024px, 768px, 480px)
│   └── animations.css          # Subtle GPU-accelerated motion & reduced-motion support
├── js/
│   ├── main.js                 # Global navigation, mobile toggle, smooth scrolling
│   ├── services.js             # Dynamic service loading & modal triggers
│   ├── portfolio.js            # Showcase cards & filtering
│   └── forms.js                # Inquiry validation & WhatsApp URL encoding
├── data/
│   └── services.json           # Structured service descriptions and pricing data
├── assets/
│   └── images/                 # Optimized local JPEG image assets
├── README.md                   # Setup, testing, and deployment documentation
└── LICENSES-AND-ASSETS.md      # Licensing information for code and assets
```

---

## 2. Setup & Local Testing

### Option A: Direct Browser Opening
Because all internal paths are relative, you can double-click `index.html` or open it in any modern web browser (Chrome, Edge, Firefox, Safari).

### Option B: Local Web Server (Recommended for JSON fetching)
For dynamic JSON features in `services.html`, run a lightweight local static server:
```bash
# Using Python 3
python3 -m http.server 8080

# Using Node.js npx
npx serve .
```
Then visit `http://localhost:8080` in your browser.

---

## 3. Working Features vs. Backend Integration Points

| Feature | Immediate Working Status | Integration / Production Step |
| :--- | :--- | :--- |
| **Mobile Navigation** | Fully functional (hamburger toggle, responsive transitions) | Ready for production. |
| **WhatsApp Dispatch** | Fully functional (URL-encodes name, service, budget, and brief) | Replace `AGENCY_WHATSAPP_NUMBER` in `js/forms.js` with your active number. |
| **Inquiry Form Validation** | Fully functional (validates name, email format, brief length) | Wire `fetch('/api/contact', { ... })` in `js/forms.js` to your Formspree, SendGrid, or serverless API. |
| **Service & Portfolio Filters** | Fully functional in browser | Can be updated by editing `data/services.json`. |
| **Dark Theme & Typography** | Fully styled with WCAG AA compliance and `prefers-reduced-motion` | Configurable in `css/style.css`. |

---

## 4. Placeholders to Customize Before Launch

1. **Agency Name & Branding**: Search and replace `AURA Digital` with your company name.
2. **Contact Email**: Update `contact@auradigital.agency` with your real inquiries mailbox.
3. **WhatsApp Phone**: Update `+1 (555) 019-2834` in `contact.html` and `js/forms.js`.
4. **Service Pricing**: Adjust starting rates in `data/services.json` and `pricing.html` to reflect your custom rates.
5. **Portfolio Projects**: Replace demo project descriptions and screenshots with your verified client work.

---

## 5. Deployment Instructions

### Deploy to Netlify / Vercel
1. Drag and drop the `digital-agency-website/` directory directly into Netlify Drop (or push to GitHub and import).
2. Set Build Command: `(leave blank)`
3. Set Publish Directory: `.` (or root of directory).

### Deploy to GitHub Pages
1. Push the folder contents to your repository's `main` branch.
2. Under Repository **Settings → Pages**, select **Branch: main**, **Folder: /(root)**, and click **Save**.

### Deploy to Cloudflare Pages
1. Connect your repository, select Framework: **None / Static HTML**, and deploy.

---

## 6. Verification & Quality Assurance Report

The codebase has undergone verification across the following parameters:
- **Navigation & Links**: All internal navigation links between `index.html`, `services.html`, `portfolio.html`, `about.html`, `pricing.html`, and `contact.html` resolve without 404 errors.
- **Mobile Responsive Layout**: Tested at 360px, 390px, 768px, 1024px, and 1440px viewports; no horizontal overflow or clipped typography.
- **Form Validation**: Tested empty submissions, invalid email formats, and successful submissions.
- **WhatsApp String Encoding**: Verified URL formatting with space and punctuation encoding.
- **Contrast & Accessibility**: Tested with WCAG AA compliant text colors on dark obsidian surfaces.
