# Licenses and Asset Declarations

This document details the licensing, attribution, and distribution terms for all assets included in the **AURA Digital** package.

---

## 1. Code & Markup License

All HTML5, CSS3, and JavaScript files in this distribution are released under the **Apache License, Version 2.0**.
You are free to use, modify, redistribute, and commercially deploy this website for client commissions or private agency operations.

```
Copyright 2026 AURA Digital Agency Authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

---

## 2. Visual Assets & Imagery

- **Image Assets in `assets/images/`**:
  - `hero.jpg`: Bespoke digital agency studio interior composition.
  - `web-dev.jpg`: Bespoke responsive web development UI showcase.
  - `video.jpg`: High-definition video editing & color grading workspace.
  - `music.jpg`: Creative audio production & album artwork studio.
- **Redistribution Terms**:
  All generated image assets were synthesized specifically for this project distribution and are provided royalty-free for personal, commercial, and agency portfolio use.

---

## 3. Typography & Fonts

- Google Fonts (`Outfit`, `Plus Jakarta Sans`, `JetBrains Mono`) are licensed under the **SIL Open Font License (OFL)**.
- System font fallbacks (`-apple-system`, `BlinkMacSystemFont`, `Segoe UI`, `Roboto`) are natively rendered by client operating systems.

---

## 4. Policy Compliance

- **Music Streaming Platforms**: No claim of direct partnership, certification, or exclusivity with Spotify, Apple Music, or YouTube Music is made.
- **Google Knowledge Panels**: Google algorithmically controls knowledge panel generation and indexing. No representation of guaranteed creation is made.
